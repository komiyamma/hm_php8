/* This is a generated file, edit the .stub.php file instead.
 * Stub hash: cf905a693064ae31b6434e84f6c63bf7c9b804a6 */

ZEND_BEGIN_ARG_INFO_EX(arginfo_class_IntlIterator_current, 0, 0, 0)
ZEND_END_ARG_INFO()

#define arginfo_class_IntlIterator_key arginfo_class_IntlIterator_current

#define arginfo_class_IntlIterator_next arginfo_class_IntlIterator_current

#define arginfo_class_IntlIterator_rewind arginfo_class_IntlIterator_current

#define arginfo_class_IntlIterator_valid arginfo_class_IntlIterator_current


ZEND_METHOD(IntlIterator, current);
ZEND_METHOD(IntlIterator, key);
ZEND_METHOD(IntlIterator, next);
ZEND_METHOD(IntlIterator, rewind);
ZEND_METHOD(IntlIterator, valid);


static const zend_function_entry class_IntlIterator_methods[] = {
	ZEND_ME(IntlIterator, current, arginfo_class_IntlIterator_current, ZEND_ACC_PUBLIC)
	ZEND_ME(IntlIterator, key, arginfo_class_IntlIterator_key, ZEND_ACC_PUBLIC)
	ZEND_ME(IntlIterator, next, arginfo_class_IntlIterator_next, ZEND_ACC_PUBLIC)
	ZEND_ME(IntlIterator, rewind, arginfo_class_IntlIterator_rewind, ZEND_ACC_PUBLIC)
	ZEND_ME(IntlIterator, valid, arginfo_class_IntlIterator_valid, ZEND_ACC_PUBLIC)
	ZEND_FE_END
};
